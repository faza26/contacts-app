const getData = () => {
    return [
      {
        id: 1,
        name: 'Aufa Zaki',
        tag: 'aufa_zaki_ahmad',
        imageUrl: '/images/Zaki.jpg',
      },
      {
        id: 2,
        name: 'Faiz Haidar',
        tag: 'faizhaidar',
        imageUrl: '/images/faiz.png',
      },
      {
        id: 3,
        name: 'Feirdaus Afrilian',
        tag: 'feirdaus17',
        imageUrl: '/images/feirdaus.jpg',
      },
      {
        id: 4,
        name: 'Syahdan Nur Karim',
        tag: 'syahdan257',
        imageUrl: '/images/syahdan.jpg',
      }
    ];
   }
    
   export { getData };